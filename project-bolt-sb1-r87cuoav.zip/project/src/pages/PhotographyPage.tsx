import React from 'react';
import { motion } from 'framer-motion';
import { Camera, Image, Aperture, Focus } from 'lucide-react';

const photographyProjects = [
  {
    id: 1,
    title: 'Architecture Photography',
    client: 'Coastal Designs',
    image: 'https://images.pexels.com/photos/2988865/pexels-photo-2988865.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Professional architectural and interior photography showcasing innovative design solutions and spatial relationships.',
    services: ['Architectural Photography', 'Interior Shots', 'Detail Photography', 'Lifestyle Images'],
    year: '2024'
  },
  {
    id: 2,
    title: 'Luxury Hotel Photography',
    client: 'Metropolitan Luxury Hotels',
    image: 'https://images.pexels.com/photos/1024248/pexels-photo-1024248.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Comprehensive hotel photography capturing the luxury experience, amenities, and sophisticated atmosphere.',
    services: ['Hotel Photography', 'Amenity Shots', 'Guest Experience', 'Marketing Images'],
    year: '2024'
  },
  {
    id: 3,
    title: 'Furniture Product Shoot',
    client: 'Artisan Furniture Co.',
    image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'High-end product photography for handcrafted furniture collection emphasizing craftsmanship and material quality.',
    services: ['Product Photography', 'Detail Shots', 'Lifestyle Styling', 'E-commerce Images'],
    year: '2023'
  },
  {
    id: 4,
    title: 'Design Studio Portraits',
    client: 'Urban Design Co.',
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Professional team portraits and workspace photography capturing the creative energy and collaborative spirit.',
    services: ['Team Portraits', 'Workspace Photography', 'Creative Process', 'Brand Photography'],
    year: '2024'
  },
  {
    id: 5,
    title: 'Sustainable Interiors',
    client: 'EcoSpace Interiors',
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Environmental photography showcasing sustainable design practices and eco-friendly interior solutions.',
    services: ['Environmental Photography', 'Sustainable Materials', 'Natural Lighting', 'Green Spaces'],
    year: '2023'
  }
];

const photographyServices = [
  {
    icon: Camera,
    title: 'Brand Photography',
    description: 'Professional photography that captures your brand essence and tells your story visually.'
  },
  {
    icon: Image,
    title: 'Product Photography',
    description: 'High-quality product shots that showcase details and drive sales conversions.'
  },
  {
    icon: Aperture,
    title: 'Architectural Photography',
    description: 'Stunning architectural and interior photography that highlights design excellence.'
  },
  {
    icon: Focus,
    title: 'Event Coverage',
    description: 'Comprehensive event photography capturing key moments and brand experiences.'
  }
];

const PhotographyPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="flex items-center justify-center mb-6">
              <Camera className="text-orange-500 mr-3" size={40} />
              <span className="text-orange-500 font-semibold text-lg tracking-wide">PROFESSIONAL PHOTOGRAPHY</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              Capturing <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">Excellence</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              We create stunning photography that showcases your brand, products, and spaces with artistic vision and technical precision.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Photography Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional photography services that capture your brand's essence and showcase your work in the best light.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {photographyServices.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="text-center group"
              >
                <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                  <service.icon className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Photography Portfolio</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A showcase of our photography work across various industries and creative projects.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {photographyProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {project.year}
                  </div>
                </div>
                
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-orange-500 font-medium mb-4">{project.client}</p>
                  <p className="text-gray-600 mb-6 leading-relaxed">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {project.services.map((service) => (
                      <span
                        key={service}
                        className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium group-hover:bg-orange-100 group-hover:text-orange-700 transition-colors duration-300"
                      >
                        {service}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 to-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready for a Professional Shoot?
            </h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Let's create stunning photography that showcases your brand, products, or spaces with artistic excellence.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-10 py-4 rounded-full font-semibold transition-all duration-300 shadow-xl"
            >
              Book Your Photography Session
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default PhotographyPage;