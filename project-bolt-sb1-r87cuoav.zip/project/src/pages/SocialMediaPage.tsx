import React from 'react';
import { motion } from 'framer-motion';
import { Share2, TrendingUp, Users, BarChart3 } from 'lucide-react';

const socialProjects = [
  {
    id: 1,
    title: 'Design Trends Campaign',
    client: 'Elegant Spaces Studio',
    image: 'https://images.pexels.com/photos/1591056/pexels-photo-1591056.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Social media marketing campaign showcasing latest interior design trends with 300% engagement increase and 150% follower growth.',
    metrics: ['300% Engagement', '150% Followers', '50+ Leads', '25% Conversion'],
    year: '2024'
  },
  {
    id: 2,
    title: 'Luxury Hotel Social Strategy',
    client: 'Metropolitan Luxury Hotels',
    image: 'https://images.pexels.com/photos/1024248/pexels-photo-1024248.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Comprehensive social media strategy for luxury hotel chain focusing on experiential content and guest storytelling.',
    metrics: ['500K Reach', '200% Bookings', '85% Satisfaction', '40+ UGC Posts'],
    year: '2024'
  },
  {
    id: 3,
    title: 'Sustainable Design Movement',
    client: 'EcoSpace Interiors',
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Educational campaign promoting sustainable interior design practices with community building and thought leadership.',
    metrics: ['1M Impressions', '400% Engagement', '75+ Shares', '30% Lead Gen'],
    year: '2023'
  },
  {
    id: 4,
    title: 'Furniture Launch Campaign',
    client: 'Artisan Furniture Co.',
    image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Product launch campaign for handcrafted furniture collection with influencer partnerships and user-generated content.',
    metrics: ['250K Views', '180% Sales', '60+ Influencers', '95% Sentiment'],
    year: '2023'
  },
  {
    id: 5,
    title: 'Design Studio Rebrand',
    client: 'Urban Design Co.',
    image: 'https://images.pexels.com/photos/276724/pexels-photo-276724.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Complete social media rebrand and content strategy for contemporary design studio targeting urban professionals.',
    metrics: ['400% Growth', '250% Engagement', '100+ Clients', '90% Retention'],
    year: '2024'
  }
];

const socialServices = [
  {
    icon: TrendingUp,
    title: 'Content Strategy',
    description: 'Data-driven content planning that aligns with your brand goals and audience preferences.'
  },
  {
    icon: Users,
    title: 'Community Management',
    description: 'Building and nurturing engaged communities around your brand with authentic interactions.'
  },
  {
    icon: BarChart3,
    title: 'Analytics & Insights',
    description: 'Comprehensive reporting and optimization based on performance metrics and audience behavior.'
  },
  {
    icon: Share2,
    title: 'Campaign Management',
    description: 'End-to-end campaign execution from concept to measurement and optimization.'
  }
];

const SocialMediaPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="flex items-center justify-center mb-6">
              <Share2 className="text-orange-500 mr-3" size={40} />
              <span className="text-orange-500 font-semibold text-lg tracking-wide">SOCIAL MEDIA MARKETING</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              Social <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">Engagement</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              We create compelling social media strategies that build communities, drive engagement, and convert followers into loyal customers.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Social Media Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive social media solutions that amplify your brand voice and drive meaningful engagement.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {socialServices.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="text-center group"
              >
                <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                  <service.icon className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Social Media Campaigns</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Successful campaigns that have driven real results for our clients across various platforms.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {socialProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {project.year}
                  </div>
                </div>
                
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-orange-500 font-medium mb-4">{project.client}</p>
                  <p className="text-gray-600 mb-6 leading-relaxed">{project.description}</p>
                  
                  <div className="grid grid-cols-2 gap-3">
                    {project.metrics.map((metric) => (
                      <div
                        key={metric}
                        className="bg-gray-50 text-gray-700 px-3 py-2 rounded-lg text-sm font-medium text-center group-hover:bg-orange-50 group-hover:text-orange-700 transition-colors duration-300"
                      >
                        {metric}
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 to-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready to Amplify Your Social Presence?
            </h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Let's create a social media strategy that builds your community and drives real business results.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-10 py-4 rounded-full font-semibold transition-all duration-300 shadow-xl"
            >
              Start Your Social Campaign
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default SocialMediaPage;