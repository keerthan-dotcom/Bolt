import React from 'react';
import { motion } from 'framer-motion';
import { Palette, Award, Target, Zap } from 'lucide-react';

const brandingProjects = [
  {
    id: 1,
    title: 'Luxe Interior Studio',
    client: 'Elegant Spaces Studio',
    image: 'https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Complete brand identity for a high-end interior design firm including logo, business cards, and comprehensive marketing materials.',
    services: ['Logo Design', 'Brand Guidelines', 'Business Cards', 'Marketing Materials'],
    year: '2024'
  },
  {
    id: 2,
    title: 'Boutique Hotel Brand',
    client: 'Metropolitan Luxury Hotels',
    image: 'https://images.pexels.com/photos/1024248/pexels-photo-1024248.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Luxury branding project for boutique hotel chain including visual identity and complete marketing collateral system.',
    services: ['Brand Strategy', 'Visual Identity', 'Signage Design', 'Digital Assets'],
    year: '2024'
  },
  {
    id: 3,
    title: 'Modern Architecture Firm',
    client: 'Coastal Designs',
    image: 'https://images.pexels.com/photos/2988865/pexels-photo-2988865.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Contemporary brand identity reflecting innovative architectural approach with clean, minimalist design principles.',
    services: ['Logo Design', 'Brand Book', 'Stationery', 'Website Graphics'],
    year: '2023'
  },
  {
    id: 4,
    title: 'Sustainable Living Brand',
    client: 'EcoSpace Interiors',
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Eco-friendly brand identity emphasizing sustainability and natural materials in interior design.',
    services: ['Eco Brand Strategy', 'Sustainable Materials', 'Green Messaging', 'Packaging Design'],
    year: '2023'
  },
  {
    id: 5,
    title: 'Luxury Furniture Collection',
    client: 'Artisan Furniture Co.',
    image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Premium brand identity for handcrafted furniture collection targeting high-end residential market.',
    services: ['Luxury Branding', 'Product Catalogs', 'Trade Show Materials', 'Digital Presence'],
    year: '2023'
  },
  {
    id: 6,
    title: 'Contemporary Design Studio',
    client: 'Urban Design Co.',
    image: 'https://images.pexels.com/photos/276724/pexels-photo-276724.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Bold, contemporary brand identity for modern interior design studio specializing in urban spaces.',
    services: ['Brand Identity', 'Digital Assets', 'Social Media Kit', 'Presentation Templates'],
    year: '2024'
  }
];

const brandingProcess = [
  {
    icon: Target,
    title: 'Discovery & Strategy',
    description: 'We dive deep into your brand\'s core values, target audience, and competitive landscape to develop a strategic foundation.'
  },
  {
    icon: Palette,
    title: 'Creative Development',
    description: 'Our designers craft multiple creative concepts, exploring different visual directions that align with your brand strategy.'
  },
  {
    icon: Zap,
    title: 'Refinement & Execution',
    description: 'We refine the chosen concept and develop a comprehensive brand system with guidelines for consistent application.'
  },
  {
    icon: Award,
    title: 'Launch & Support',
    description: 'We help implement your new brand across all touchpoints and provide ongoing support for brand consistency.'
  }
];

const BrandingPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="flex items-center justify-center mb-6">
              <Palette className="text-orange-500 mr-3" size={40} />
              <span className="text-orange-500 font-semibold text-lg tracking-wide">BRANDING EXCELLENCE</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              Brand <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">Identity</span> Design
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              We create powerful brand identities that tell your story, connect with your audience, and drive business growth through strategic design thinking.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Branding Process</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A systematic approach to creating memorable brands that resonate with your target audience.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {brandingProcess.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center group"
              >
                <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                  <step.icon className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{step.title}</h3>
                <p className="text-gray-600 leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Branding Portfolio</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore our collection of brand identity projects that have helped businesses stand out and succeed.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {brandingProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {project.year}
                  </div>
                </div>
                
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-orange-500 font-medium mb-4">{project.client}</p>
                  <p className="text-gray-600 mb-6 leading-relaxed">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {project.services.map((service) => (
                      <span
                        key={service}
                        className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium group-hover:bg-orange-100 group-hover:text-orange-700 transition-colors duration-300"
                      >
                        {service}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 to-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready to Build Your Brand?
            </h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Let's create a brand identity that captures your vision and connects with your audience.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-10 py-4 rounded-full font-semibold transition-all duration-300 shadow-xl"
            >
              Start Your Branding Project
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default BrandingPage;