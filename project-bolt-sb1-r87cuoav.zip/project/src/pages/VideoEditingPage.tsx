import React from 'react';
import { motion } from 'framer-motion';
import { Video, Film, Play, Edit3 } from 'lucide-react';

const videoProjects = [
  {
    id: 1,
    title: 'Studio Showcase Video',
    client: 'Elegant Spaces Studio',
    image: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Professional video production showcasing interior design process from initial concept to final completion with cinematic quality.',
    deliverables: ['2-minute Showcase', 'Social Media Cuts', 'Behind-the-Scenes', 'Client Testimonials'],
    year: '2024'
  },
  {
    id: 2,
    title: 'Hotel Experience Film',
    client: 'Metropolitan Luxury Hotels',
    image: 'https://images.pexels.com/photos/1024248/pexels-photo-1024248.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Luxury hotel experience video highlighting amenities, services, and guest journey with emotional storytelling approach.',
    deliverables: ['Brand Film', 'Room Tours', 'Amenity Highlights', 'Guest Stories'],
    year: '2024'
  },
  {
    id: 3,
    title: 'Architecture Documentary',
    client: 'Coastal Designs',
    image: 'https://images.pexels.com/photos/2988865/pexels-photo-2988865.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Documentary-style video exploring sustainable architecture practices and innovative design solutions for coastal environments.',
    deliverables: ['Documentary Film', 'Process Videos', 'Time-lapse', 'Interview Segments'],
    year: '2023'
  },
  {
    id: 4,
    title: 'Product Launch Series',
    client: 'Artisan Furniture Co.',
    image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Multi-part video series showcasing handcrafted furniture creation process and artisan craftsmanship stories.',
    deliverables: ['Launch Video', 'Craft Process', 'Artisan Profiles', 'Product Demos'],
    year: '2023'
  },
  {
    id: 5,
    title: 'Design Studio Culture',
    client: 'Urban Design Co.',
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Company culture video highlighting team creativity, collaborative process, and innovative design approach.',
    deliverables: ['Culture Video', 'Team Profiles', 'Office Tour', 'Design Process'],
    year: '2024'
  }
];

const videoServices = [
  {
    icon: Video,
    title: 'Commercial Videos',
    description: 'Professional brand videos that tell your story and showcase your expertise.'
  },
  {
    icon: Film,
    title: 'Documentary Style',
    description: 'In-depth storytelling that explores your process, values, and unique approach.'
  },
  {
    icon: Play,
    title: 'Social Content',
    description: 'Engaging short-form content optimized for social media platforms and audiences.'
  },
  {
    icon: Edit3,
    title: 'Post-Production',
    description: 'Expert editing, color grading, sound design, and motion graphics for polished results.'
  }
];

const VideoEditingPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="flex items-center justify-center mb-6">
              <Video className="text-orange-500 mr-3" size={40} />
              <span className="text-orange-500 font-semibold text-lg tracking-wide">VIDEO PRODUCTION & EDITING</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              Visual <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">Storytelling</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              We create compelling video content that captures attention, tells your story, and drives action through professional production and expert editing.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Video Production Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From concept to final cut, we handle every aspect of video production with cinematic quality and attention to detail.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {videoServices.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="text-center group"
              >
                <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                  <service.icon className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Video Portfolio</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore our video production work that has helped brands tell their stories and connect with audiences.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {videoProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Play className="text-white" size={48} />
                  </div>
                  <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {project.year}
                  </div>
                </div>
                
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-orange-500 font-medium mb-4">{project.client}</p>
                  <p className="text-gray-600 mb-6 leading-relaxed">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {project.deliverables.map((deliverable) => (
                      <span
                        key={deliverable}
                        className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium group-hover:bg-orange-100 group-hover:text-orange-700 transition-colors duration-300"
                      >
                        {deliverable}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 to-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready to Tell Your Story?
            </h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Let's create compelling video content that showcases your brand and engages your audience.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-10 py-4 rounded-full font-semibold transition-all duration-300 shadow-xl"
            >
              Start Your Video Project
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default VideoEditingPage;