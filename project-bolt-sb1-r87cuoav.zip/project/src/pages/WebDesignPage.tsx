import React from 'react';
import { motion } from 'framer-motion';
import { Monitor, Smartphone, Globe, Code } from 'lucide-react';

const webProjects = [
  {
    id: 1,
    title: 'Modern Living Spaces',
    client: 'Elegant Spaces Studio',
    image: 'https://images.pexels.com/photos/276724/pexels-photo-276724.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Responsive website design and development for interior design showcase with interactive portfolio and client management system.',
    technologies: ['React', 'Tailwind CSS', 'Node.js', 'MongoDB'],
    year: '2024'
  },
  {
    id: 2,
    title: 'Luxury Hotel Website',
    client: 'Metropolitan Luxury Hotels',
    image: 'https://images.pexels.com/photos/1024248/pexels-photo-1024248.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Premium hotel booking platform with immersive virtual tours and seamless reservation system.',
    technologies: ['Next.js', 'TypeScript', 'Stripe', 'Prisma'],
    year: '2024'
  },
  {
    id: 3,
    title: 'Architecture Portfolio',
    client: 'Coastal Designs',
    image: 'https://images.pexels.com/photos/2988865/pexels-photo-2988865.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Stunning portfolio website showcasing architectural projects with 3D visualizations and interactive galleries.',
    technologies: ['Vue.js', 'Three.js', 'GSAP', 'Contentful'],
    year: '2023'
  },
  {
    id: 4,
    title: 'E-commerce Platform',
    client: 'Artisan Furniture Co.',
    image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Custom e-commerce solution for luxury furniture with AR visualization and personalized shopping experience.',
    technologies: ['Shopify Plus', 'React', 'AR.js', 'Custom APIs'],
    year: '2023'
  },
  {
    id: 5,
    title: 'Design Studio Platform',
    client: 'Urban Design Co.',
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    description: 'Comprehensive platform for design collaboration with project management and client communication tools.',
    technologies: ['React', 'Firebase', 'WebRTC', 'Canvas API'],
    year: '2024'
  }
];

const webServices = [
  {
    icon: Monitor,
    title: 'Responsive Design',
    description: 'Websites that look perfect on every device and screen size.'
  },
  {
    icon: Smartphone,
    title: 'Mobile-First Approach',
    description: 'Optimized for mobile users with fast loading and intuitive navigation.'
  },
  {
    icon: Globe,
    title: 'SEO Optimization',
    description: 'Built with search engine optimization best practices for maximum visibility.'
  },
  {
    icon: Code,
    title: 'Custom Development',
    description: 'Tailored functionality and features specific to your business needs.'
  }
];

const WebDesignPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="flex items-center justify-center mb-6">
              <Monitor className="text-orange-500 mr-3" size={40} />
              <span className="text-orange-500 font-semibold text-lg tracking-wide">WEB DESIGN & DEVELOPMENT</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              Digital <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">Experiences</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              We design and develop stunning websites that not only look amazing but also deliver exceptional user experiences and drive business results.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">What We Deliver</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive web solutions that combine beautiful design with powerful functionality.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {webServices.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="text-center group"
              >
                <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                  <service.icon className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Web Design Portfolio</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover our latest web design and development projects that showcase our expertise and creativity.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {webProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {project.year}
                  </div>
                </div>
                
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-orange-500 font-medium mb-4">{project.client}</p>
                  <p className="text-gray-600 mb-6 leading-relaxed">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium group-hover:bg-orange-100 group-hover:text-orange-700 transition-colors duration-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 to-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready to Launch Your Website?
            </h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Let's create a digital experience that showcases your brand and drives business growth.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-10 py-4 rounded-full font-semibold transition-all duration-300 shadow-xl"
            >
              Start Your Web Project
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default WebDesignPage;