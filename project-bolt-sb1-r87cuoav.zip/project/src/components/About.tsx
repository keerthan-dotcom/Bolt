import React from 'react';
import { Award, Users, Clock, Target } from 'lucide-react';
import { motion } from 'framer-motion';

const stats = [
  { icon: Users, value: '50+', label: 'Happy Clients' },
  { icon: Award, value: '200+', label: 'Projects Completed' },
  { icon: Clock, value: '5+', label: 'Years Experience' },
  { icon: Target, value: '98%', label: 'Client Satisfaction' }
];

const About = () => {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">
              About <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-orange-600">Graystag</span>
            </h2>
            <div className="space-y-6 text-gray-600 leading-relaxed text-lg">
              <p>
                We're a passionate creative agency dedicated to helping brands tell their stories through exceptional design and strategic thinking. Our multidisciplinary approach combines artistry with strategy to deliver results that matter.
              </p>
              <p>
                Founded with the vision of bridging the gap between creativity and business success, we've built lasting partnerships with clients across various industries, with particular expertise in the interior design sector.
              </p>
              <p>
                Our team of designers, strategists, and creatives work collaboratively to ensure every project not only looks amazing but also drives real business results for our clients.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.05 }}
                  className="text-center group"
                >
                  <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                    <stat.icon className="text-white" size={24} />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                  <div className="text-gray-600 text-sm">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative z-10">
              <motion.img
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.3 }}
                src="https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
                alt="Creative team at work"
                className="rounded-2xl shadow-2xl w-full"
              />
            </div>
            <motion.div
              animate={{ 
                rotate: [0, 1, -1, 0],
                scale: [1, 1.02, 1]
              }}
              transition={{ 
                duration: 6,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute -top-6 -right-6 w-full h-full bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl -z-10"
            ></motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;