import React from 'react';
import { Link } from 'react-router-dom';
import { Palette, Monitor, Share2, Video, Camera, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const services = [
  {
    icon: Palette,
    title: 'Branding',
    path: '/branding',
    description: 'Complete brand identity design that captures your unique essence and builds lasting connections.',
    features: ['Logo Design', 'Brand Guidelines', 'Color Systems', 'Typography'],
    gradient: 'from-orange-500 to-red-500'
  },
  {
    icon: Monitor,
    title: 'Web Design',
    path: '/web-design',
    description: 'Modern, responsive websites that deliver exceptional user experiences and drive conversions.',
    features: ['Responsive Design', 'User Experience', 'E-commerce', 'Development'],
    gradient: 'from-orange-500 to-yellow-500'
  },
  {
    icon: Share2,
    title: 'Social Media',
    path: '/social-media',
    description: 'Strategic campaigns that build engagement, grow your following, and convert prospects.',
    features: ['Content Strategy', 'Campaign Management', 'Analytics', 'Community'],
    gradient: 'from-orange-500 to-pink-500'
  },
  {
    icon: Video,
    title: 'Video Editing',
    path: '/video-editing',
    description: 'Professional video production that tells your story through compelling visual narratives.',
    features: ['Commercial Videos', 'Social Content', 'Motion Graphics', 'Post-Production'],
    gradient: 'from-orange-500 to-purple-500'
  },
  {
    icon: Camera,
    title: 'Photography',
    path: '/photography',
    description: 'High-quality photography capturing your brand, products, and moments with artistic excellence.',
    features: ['Product Photography', 'Brand Photography', 'Event Coverage', 'Portraits'],
    gradient: 'from-orange-500 to-blue-500'
  }
];

const Services = () => {
  return (
    <section id="services" className="py-24 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-orange-600">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            From concept to execution, we provide comprehensive creative solutions that elevate your brand and drive measurable results.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
              className="group relative"
            >
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform group-hover:scale-105 border border-gray-100 overflow-hidden">
                {/* Gradient Background on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}></div>
                
                <div className="relative z-10">
                  <motion.div
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                    className={`bg-gradient-to-br ${service.gradient} w-16 h-16 rounded-xl flex items-center justify-center mb-6 shadow-lg`}
                  >
                    <service.icon className="text-white" size={32} />
                  </motion.div>

                  <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-gray-800 transition-colors duration-300">
                    {service.title}
                  </h3>
                  
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {service.description}
                  </p>

                  <ul className="space-y-3 mb-8">
                    {service.features.map((feature, featureIndex) => (
                      <motion.li
                        key={feature}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ delay: (index * 0.1) + (featureIndex * 0.05) }}
                        viewport={{ once: true }}
                        className="flex items-center text-gray-700"
                      >
                        <div className="w-2 h-2 bg-orange-500 rounded-full mr-3 group-hover:scale-125 transition-transform duration-300"></div>
                        {feature}
                      </motion.li>
                    ))}
                  </ul>

                  <Link
                    to={service.path}
                    className="inline-flex items-center text-orange-500 hover:text-orange-600 font-semibold transition-all duration-300 group-hover:translate-x-2"
                  >
                    View Projects
                    <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform duration-300" size={20} />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;